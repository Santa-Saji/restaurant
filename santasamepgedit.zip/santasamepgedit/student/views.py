
from django.shortcuts import render,redirect
from.models import Student
# Create your views here.

def add_student(request):
    student=Student.objects.all()
    if request.method=="POST":
        name=request.POST.get('name')
        department=request.POST.get('dept')
        score=request.POST.get('score')
        Student.objects.create(
            name=name,
            department=department,
            score=score,
        )
        return redirect(add_student)
    else:
        return render(request,'student.html',{'STUDENTS':student})


def delete(request,id):
        #if request.method=='POST':
        de=Student.objects.get(id=id)
        de.delete()   
        return redirect(add_student)
      
def edit(request,id):
        stu=Student.objects.get(id=id)
        student=Student.objects.all()
        form={'stu':stu,'STUDENTS':student} #'STUDENTS' must be the key in fftn add_student else part key
        return render(request,'student.html',form) 
         
'''def update(request,id):
        upd=Student.objects.get(id=id)
        upd.name=request.POST['name']
        upd.price=request.POST['dept']
        upd.score=request.POST['score']
        
       
        upd.save()
        return redirect(add_student)  
'''

