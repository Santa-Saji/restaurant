
from django.http import HttpResponse  
from django.views import View  
from django.shortcuts import redirect, render
from.forms import *
from.models import *


# Create your views here.

class NewView(View):
    def get(self,request):
        return HttpResponse('Hello all')
    
class Studentcreate(View):
    def get(self,request):
        form=StudentForm()
        return render(request,'student.html',{'form':form})
    
    def post(self,request):
        form=StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('myapp:Student')
        return render(request, 'student.html', {'form': form})
    
class StudentList(View):
    def get(self, request):
        students = Student.objects.all()
        return render(request, 'show.html', {'students': students})

class StudentDelete(View):
    def post(self, request, id):
        student = Student.objects.get(id=id)
        student.delete()
        return redirect('myapp:ShowStudent')
    
class StudentEdit(View):
     def get(self, request, id):    
         stuedit=Student.objects.get(id=id)
         form=StudentForm(instance=stuedit)
         return render(request,'edit.html',{'form':form})

     def post(self, request, id):
        stu =Student.objects.get(id=id)
        form = StudentForm(request.POST, request.FILES, instance=stu)  #request.FILES,-used for if images are there

        if form.is_valid():
            form.save()
            return redirect('myapp:ShowStudent')

        return render(request, 'edit.html', {'form': form})

   
    



