
from django.shortcuts import render,redirect
from.models import Student
# Create your views here.

def add_student(request):
    student=Student.objects.all()
    if request.method=="POST":
        name=request.POST.get('name')
        department=request.POST.get('dept')
        score=request.POST.get('score')
        Student.objects.create(
            name=name,
            department=department,
            score=score,
        )
        return redirect(add_student)
    else:
        return render(request,'student.html',{'STUDENTS':student})




