from django.shortcuts import render, get_object_or_404,redirect
from.models import *
from django.contrib import messages
from django.contrib.auth.models import auth,User 

# Create your views here.
def index(request):
    prod=Product.objects.all()
    return render(request,'base.html',{'prod':prod})
def about(request):
    return render(request,'about.html')
def contact(request):
    return render(request,'contact.html')
def product(request):
    prod=Product.objects.all()
    return render(request,'product.html',{'prod':prod})

def product_detail(request, id):
    prod=Product.objects.get(id=id)
   
    return render(request, 'product_detail.html', {'prod': prod})


def buy_now(request, id):
    if not request.user.is_authenticated:
        return redirect('register.html')
    if request.method=='POST':
        username=request.POST['username']
        password=request.POST['password']
        user=auth.authenticate(username=username,password=password)
        if user is not None:
            auth.login(request,user)
            return render('/')
        else:
            messages.info(request,'invalid')
            return redirect('login')    
    else:
        return render(request,'login.html')
   
    
   

