from django.urls import path
from.import views

urlpatterns = [
    path('',views.index,name='index'),
    path('about/',views.about,name='about'),
    path('contact/',views.contact,name='contact'),
    path('product/',views.product,name='product'),
    path('product/<int:id>/', views.product_detail, name='product_detail'),
    path('buy/', views.buy_now, name='buy_now'),
    #path('register/', views.register, name='register'),
    #path('login/', views.login_view, name='login'),
    #path('logout/', views.logout_view, name='logout'),

]