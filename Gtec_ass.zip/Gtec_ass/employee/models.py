from django.db import models

# Create your models here.
class Employee(models.Model):
    name=models.CharField(max_length=30)
    job=models.CharField(max_length=30)
    department=models.CharField(max_length=30)
    basic_pay=models.IntegerField()
    dob=models.DateField()
    
    def __str__(self):
        return self.name