from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import *
from employee.forms import Employeeform

# Create your views here.
#adding employee details
def employee_det(request):
    form=Employeeform()
    emp=Employee.objects.all()
    if request.method=='POST':
        form=Employeeform(request.POST)
        
        if form.is_valid():
            form.save()
            return redirect('employee_det')
    return render(request,'employee.html',{'employeeform':form,'emp':emp})
def update(request,id):
    emp=Employee.objects.get(id=id)
    form=Employeeform(instance=emp)
    if request.method=='POST':
        form=Employeeform(request.POST,instance=emp)
        if form.is_valid():
            form.save()
            return redirect('employee_det')

    return render(request,'update.html',{'form':form})    
def delete(request,id):
    Employee.objects.get(id=id).delete() #if method="post" ivde kodukknda bcz in html page for delete we provide a href url link
    return redirect('employee_det')