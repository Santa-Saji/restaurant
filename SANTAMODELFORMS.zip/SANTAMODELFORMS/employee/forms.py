from django import forms
from employee.models import Employee #from employee.models import Employee -here employee.models employee is app name

class Employeeform(forms.ModelForm):
    class Meta:
        model=Employee #model name Employee
        fields='__all__'