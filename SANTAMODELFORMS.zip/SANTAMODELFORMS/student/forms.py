from django import forms
from student.models import Student #from employee.models import Employee -here employee.models employee is app name

class Studentform(forms.ModelForm):
    class Meta:
        model=Student #model name Employee
        fields='__all__'