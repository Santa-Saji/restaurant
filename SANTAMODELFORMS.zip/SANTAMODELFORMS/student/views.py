from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import *
from student.forms import Studentform

# Create your views here.
def student_det(request):
    ob=Studentform()
    student=Student.objects.all()
    if request.method=='POST':
        student=Studentform(request.POST)
        
        if student.is_valid():
            student.save()
            return redirect('student_det')
    return render(request,'student.html',{'studentmodelform':ob,'stu':student})
def update(request,id):
    stuu=Student.objects.get(id=id)
    form=Studentform(instance=stuu)
    if request.method=='POST':
        f=Studentform(request.POST,instance=stuu)
        if f.is_valid():
            f.save()
            return redirect('student_det')

    return render(request,'update1.html',{'formupdate':form})    
def delete(request,id):
    Student.objects.get(id=id).delete() #if method="post" ivde kodukknda bcz in html page for delete we provide a href url link
    return redirect('student_det')
