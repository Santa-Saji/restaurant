from django.db import models

class Student(models.Model):
    name=models.CharField(max_length=40)
    gender=models.CharField(max_length=30)
    department=models.CharField(max_length=30)
    hobbies=models.CharField(max_length=30)
    
    def __str__(self):
        return self.name
    
    def __str__(self):
        return self.department
    
  
    