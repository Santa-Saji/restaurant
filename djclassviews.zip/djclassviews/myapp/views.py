
from django.http import HttpResponse  
from django.views import View  
from django.shortcuts import redirect, render
from.forms import *
from.models import *


# Create your views here.

class NewView(View):
    def get(self,request):
        return HttpResponse('Hello')
    
class Employeecreate(View):
    def get(self,request):
        form=EmployeeForm()
        return render(request,'employee.html',{'form':form})
    
    def post(self,request):
        form=EmployeeForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('myapp:Employee')
        return render(request, 'employee.html', {'form': form})


class EmployeeList(View):
    def get(self, request):
        employees = Employee.objects.all()
        return render(request, 'show.html', {'employees': employees})


class EmployeeDelete(View):
    def post(self, request, id):
        employee = Employee.objects.get(id=id)
        employee.delete()
        return redirect('myapp:ShowEmployee')  
    
class EmployeeEdit(View):
     def get(self, request, id):    
         empedit=Employee.objects.get(id=id)
         form=EmployeeForm(instance=empedit)
         return render(request,'edit.html',{'form':form})

     def post(self, request, id):
        emp =Employee.objects.get(id=id)
        form = EmployeeForm(request.POST, request.FILES, instance=emp)  #request.FILES,-used for if images are there

        if form.is_valid():
            form.save()
            return redirect('myapp:ShowEmployee')

        return render(request, 'edit.html', {'form': form})
        
     
