
from django.urls import path  
from myapp.views import NewView  
from.views import *
from.models import *
app_name='myapp'
urlpatterns = [
    path('', NewView.as_view()),
    path('employee/',Employeecreate.as_view(),name='Employee'),
    path('show/', EmployeeList.as_view(), name='ShowEmployee'),
    path('delete/<int:id>/', EmployeeDelete.as_view(), name='DeleteEmployee'),
    path('edit/<int:id>/', EmployeeEdit.as_view(), name='EditEmployee'),
    
    
    
      
]