from django.shortcuts import render
from datetime import datetime

# Create your views here.
def greeting_view(request):
    now=datetime.now()
    hour=now.hour
    
    if hour<12:
        greeting_message="Good Morning"
    elif hour<17:
        greeting_message="Good Afternoon"
    else:
        greeting_message="Good Evening"
        
    return render(request,'greeting.html',{
        'date':now.date(),
        'time':now.time(),
        'greeting_message':greeting_message
    })