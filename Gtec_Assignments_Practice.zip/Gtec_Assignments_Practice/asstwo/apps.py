from django.apps import AppConfig


class AsstwoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'asstwo'
