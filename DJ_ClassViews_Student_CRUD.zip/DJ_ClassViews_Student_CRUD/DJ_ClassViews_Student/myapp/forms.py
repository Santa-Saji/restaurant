from django.forms import fields
from . models import Student
from django import forms

class StudentForm(forms.ModelForm):  
  
    class Meta:  
        # To specify the model to be used to create form  
        model = Student 
        # It includes all the fields of model  
        fields = '__all__'