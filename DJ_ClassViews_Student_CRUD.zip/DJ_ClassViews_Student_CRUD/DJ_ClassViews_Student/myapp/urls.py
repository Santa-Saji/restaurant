
from django.urls import path  
from myapp.views import NewView
from.views import *
from.models import *
app_name='myapp'
urlpatterns = [
    path('', NewView.as_view()),
    path('student/',Studentcreate.as_view(),name='Student'),
    path('show/', StudentList.as_view(), name='ShowStudent'),
    path('delete/<int:id>/',StudentDelete.as_view(), name='DeleteStudent'),
    path('edit/<int:id>/', StudentEdit.as_view(), name='EditStudent'),
]