from django.db import models

# Create your models here.
class Product(models.Model):
    name=models.CharField(max_length=50)
    qty=models.IntegerField()
    price=models.IntegerField()
    image = models.ImageField(upload_to='productimg')#'productimg' is the name we are giving to the folder where all the images occurs
    
    def __str__(self):
        return self.name
    
class Product1(models.Model):
    name=models.CharField(max_length=50)
    qty=models.IntegerField()
    price=models.IntegerField()
    image = models.ImageField(upload_to='productimg')#'productimg' is the name we are giving to the folder where all the images occurs
    
    def __str__(self):
        return self.name