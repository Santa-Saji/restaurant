from django.contrib import admin
from .models import *
from django.utils.html import format_html


class ProductAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'image_preview')

    def image_preview(self, obj):
        if obj.image:
            return format_html('<img src="{}" width="80" />', obj.image.url)
        return "No Image"

    image_preview.short_description = 'Image'

# Register your models here.
admin.site.register(Product1,ProductAdmin)