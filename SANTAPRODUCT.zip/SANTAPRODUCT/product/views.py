from django.shortcuts import render,redirect
from.models import Product1

# Create your views here.
def add_product(request):
    product_list=Product1.objects.all()
    if request.method=="POST":
        name=request.POST.get('name')
        quantity=request.POST.get('qty')
        price=request.POST.get('price')
        image=request.FILES.get('image')  # <- image file
        
        Product1.objects.create(
            name=name,
            qty=quantity,
            price=price,
            image=image
        )
        
        return redirect(add_product)
    else:
        return render(request,'product.html',{'PRODUCTS':product_list})

'''def delete(request,id):
    de=Product1.objects.get(id=id)
    de.delete()
    return redirect(add_product)

def edit(request,id):
    prod=Product1.objects.get(id=id)
    prodata=Product1.objects.all()
    
    form={'prod':prod,'PRODUCTS':prodata}
    return render(request,'product.html',form)

def update(request,id):
        upd=Product1.objects.get(id=id)
        upd.name=request.POST['name']
        upd.qty=request.POST['qty']
        upd.price=request.POST['price']
        upd.save()
        return redirect(add_product)'''
    

