from django.shortcuts import render
from django.http import HttpResponse  
from django.views import View

from django.urls import reverse, reverse_lazy  
from django.contrib import messages  
from .models import Employee  
from .forms import EmployeeForm
from django.views.generic.edit import CreateView, UpdateView, DeleteView  
from django.views.generic.list import ListView  
from django.views.generic.detail import DetailView 
# Create your views here.

class NewView(View):
    def get(self,request):
        return HttpResponse('HELLO')
    
class EmployeeCreate(CreateView):  
    model = Employee  
    fields = '__all__'  
    success_url = reverse_lazy('myapp:EmployeeRetrieve')  #success_url works like return redirect
  
class EmployeeRetrieve(ListView):  
    model = Employee  
    success_url = reverse_lazy('myapp:EmployeeRetrieve') #'myapp:EmployeeRetrieve' inside my app what we write is the name="" in urls.py

class EmployeeUpdate(UpdateView):  
    model = Employee  
    template_name_suffix = 'employe_update'  #template name is writing here or we can write after the underscore portion also since all has same name starting with employee
    fields = '__all__'  
    success_url = reverse_lazy('myapp:EmployeeRetrieve') 
    
class EmployeeDelete(DeleteView):  
    model = Employee  
    success_url = reverse_lazy('myapp:EmployeeRetrieve') 