from django.urls import path 
from myapp.views import NewView 
from .views import EmployeeCreate,EmployeeRetrieve,EmployeeUpdate, EmployeeDelete
app_name='myapp'
urlpatterns=[
    path('', NewView.as_view()),
    path('employee/', EmployeeCreate.as_view(template_name='employee.html')), 
    path('retrieve/', EmployeeRetrieve.as_view(template_name='employee_list.html'), name = 'EmployeeRetrieve'),
    path('<int:pk>/update/', EmployeeUpdate.as_view(template_name='employee_update.html'), name = 'EmployeeUpdate'), 
    path('<int:pk>/delete/', EmployeeDelete.as_view(template_name='employee_delete.html'), name = 'EmployeeDelete'), 
]
