from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Product(models.Model):
      
        name=models.CharField(max_length=100)
        img=models.ImageField(upload_to='images')
        desc=models.TextField()
        price=models.IntegerField()
        
        def __str__(self):
            return self.name
        

        
        
class Buy(models.Model):
        product=models.ForeignKey(Product,on_delete=models.CASCADE)
        qty=models.IntegerField()
        amt=models.IntegerField()
        user = models.ForeignKey(User, on_delete=models.CASCADE)
        def __str__(self):
                return '%s' %(self.product.name)        