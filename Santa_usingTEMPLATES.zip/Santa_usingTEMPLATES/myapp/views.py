from django.shortcuts import render, get_object_or_404,redirect
from.models import *
from django.contrib import messages
from django.contrib.auth.models import auth,User 
from django.contrib.auth.decorators import login_required


# Create your views here.
def index(request):
    prod=Product.objects.all()
    return render(request,'base.html',{'prod':prod})

def index1(request):
    prod=Product.objects.all()
    return render(request,'index1.html',{'prod':prod})
def about(request):
    return render(request,'about.html')
def contact(request):
    return render(request,'contact.html')
def product(request):
    prod=Product.objects.all()
    return render(request,'product.html',{'prod':prod})

def product_detail(request, id):
    prod=Product.objects.get(id=id)
   
    return render(request, 'product_detail.html', {'prod': prod})




def buy_now(request, id):
 
    prod = get_object_or_404(Product, id=id)
 
    if request.method == "POST":
        
        qty = request.POST.get("qty")
        amt = request.POST.get("amount")
        Buy.objects.create(user=request.user,product=prod,qty=qty, amt=amt)
        return redirect('/')  # create a success page
         
    return render(request, 'buy.html', {'prod': prod})

