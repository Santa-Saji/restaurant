from django.shortcuts import render,redirect
# Create your views here.
from .models import Student
from .forms import Studentform

def student_det(request):
    ob1=Studentform()
    stud=Student.objects.all()
    if request.POST:
        ob=Studentform(request.POST)
        if ob.is_valid():
            ob.save()
          
            return render(request,"student.html",{"studentform":ob1,"stud":stud})   #left side le stud we used in html page
    else:
        
        return render(request,"student.html",{"studentform":ob1,"stud":stud})

def edit(request,id):
    stu=Student.objects.get(id=id)
    return render(request,'edit.html',{'form':stu})
    
def delete(request,id):
    if request.method=='POST':
        de=Student.objects.get(id=id)
        de.delete()
        return redirect(student_det)

'''def delete(request,id):
    de=Student.objects.get(id=id)
    de.delete()
    return redirect(student_det)'''

def update(request,id):
    stu=Student.objects.get(id=id)
    stu.fname=request.POST['fname']
    stu.lname=request.POST['lname']
    stu.contact=request.POST['contact']
    stu.email=request.POST['email']
    stu.gender=request.POST['gender']
    stu.district=request.POST['district']
    stu.save()
    return redirect(student_det)