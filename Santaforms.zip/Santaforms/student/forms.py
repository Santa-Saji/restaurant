from django import forms
from .models import Student

class Studentform(forms.Form):
    fname=forms.CharField(
        max_length=20,
        label="First Name",
        label_suffix="",
        help_text="Enter your first name",
        required=False
        )
    lname=forms.CharField(
        max_length=20,
        label="Last Name",
        label_suffix="",
        help_text="Enter your last name",
        required=False
        )
    contact=forms.CharField(
        max_length=20,
        label="Contact",
        label_suffix="",
        help_text="Enter your mobile number",
        required=False
        )
    email=forms.CharField(
        max_length=20,
        label="Email Id",
        label_suffix="",
        help_text="Enter your email id",
        required=False
        )
    
    GENDER=[
        ("Male","Male"), #label,value
        ("Female","Female")
    ]
    gender=forms.ChoiceField(
        widget=forms.RadioSelect,choices=GENDER, required=False) #radiobuton,checkbox,dropdown -- ChoiceField

    DISTRICT=[
        ("ekm","Ernakulam"),  #label,value
        ("ktym","Kottayam"),
        ("plkd","Palakkad")
    ]
    district=forms.ChoiceField(choices=DISTRICT)

    def save(self):             #saving the details
        Student.objects.create(
            fname=self.cleaned_data["fname"], #clean data kodukkunnath bcz nml form submit cheythitt clear akn vendi in left side
            lname=self.cleaned_data["lname"],
            contact=self.cleaned_data["contact"],
            email=self.cleaned_data["email"],
            gender=self.cleaned_data["gender"],
            district=self.cleaned_data["district"]

        )
        
        
        

  
    