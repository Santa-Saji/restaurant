from django.db import models

# Create your models here.
class Student(models.Model):
    fname=models.CharField(max_length=20)
    lname=models.CharField(max_length=20)
    contact=models.CharField(max_length=20)
    email=models.CharField(max_length=20)
    gender=models.CharField(max_length=10)
    district=models.CharField(max_length=20)

    def __str__(self):
        return self.fname
    

    
