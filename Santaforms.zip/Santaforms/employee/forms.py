from django import forms
from .models import Employee

class Employeeform(forms.Form):
    fname=forms.CharField(
        max_length=20,
        label="First Name",
        label_suffix="",
        help_text="Enter your first name",
        required=False
        )
    lname=forms.CharField(
        max_length=20,
        label="Last Name",
        label_suffix="",
        help_text="Enter your last name",
        required=False
        )
    contact=forms.CharField(
        max_length=20,
        label="Contact",
        label_suffix="",
        help_text="Enter your mobile number",
        required=False
        )
    email=forms.CharField(
        max_length=20,
        label="Email Id",
        label_suffix="",
        help_text="Enter your email id",
        required=False
        )
    
    GENDER=[
        ("Male","Male"), #label,value
        ("Female","Female")
    ]
    gender=forms.ChoiceField(
        widget=forms.RadioSelect,choices=GENDER, required=False) #radiobuton,checkbox,dropdown -- ChoiceField

    DEPARTMENT=[
        ("IT","Information Technology"),  #label,value
        ("CIVIL","Civil Engineering"),
        ("MECH","Mechanical Engineering")
    ]
    department=forms.ChoiceField(choices=DEPARTMENT)

    def save(self):             #saving the details
        Employee.objects.create(
            fname=self.cleaned_data["fname"], #clean data kodukkunnath bcz nml form submit cheythitt clear akn vendi in left side
            lname=self.cleaned_data["lname"],
            contact=self.cleaned_data["contact"],
            email=self.cleaned_data["email"],
            gender=self.cleaned_data["gender"],
            department=self.cleaned_data["department"]

        )
        
        
        

  
    