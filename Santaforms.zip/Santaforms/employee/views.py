
from django.shortcuts import render,redirect
# Create your views here.
from .models import Employee
from .forms import Employeeform

def employee_det(request):
    ob1=Employeeform()
    emp=Employee.objects.all()
    if request.POST:
        ob=Employeeform(request.POST)
        if ob.is_valid():
            ob.save()
          
            return render(request,"employee.html",{"empform":ob1,"employee":emp})   #left side le stud we used in html page
    else:
        
        return render(request,"employee.html",{"empform":ob1,"employee":emp})
    
def edit(request,id):
    emp=Employee.objects.get(id=id)
    return render(request,'empedit.html',{'form':emp})
    
def delete(request,id):
    if request.method=='POST':
        de=Employee.objects.get(id=id)
        de.delete()
        return redirect(employee_det)
    
def update(request,id):
    emp=Employee.objects.get(id=id)
    emp.fname=request.POST['fname']
    emp.lname=request.POST['lname']
    emp.contact=request.POST['contact']
    emp.email=request.POST['email']
    emp.gender=request.POST['gender']
    emp.department=request.POST['department']
    emp.save()
    return redirect(employee_det)